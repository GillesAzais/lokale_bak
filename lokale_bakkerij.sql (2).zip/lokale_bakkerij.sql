--
-- Database: `lokale_bakkerij`
--
CREATE DATABASE IF NOT EXISTS `lokale_bakkerij` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `lokale_bakkerij`;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `bestellingen`
--

DROP TABLE IF EXISTS `bestellingen`;
CREATE TABLE `bestellingen` (
  `bestellingsId` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `bestellingsDatum` date NOT NULL,
  `afhaalDatum` date DEFAULT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `bestellingen`
--

INSERT INTO `bestellingen` (`bestellingsId`, `email`, `bestellingsDatum`, `afhaalDatum`, `status`) VALUES
(22, 'gillesazais@hotmail.com', '2016-02-09', NULL, 'besteld'),
(23, 'a@a.a', '2016-02-09', NULL, 'besteld');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `bestellingsorders`
--

DROP TABLE IF EXISTS `bestellingsorders`;
CREATE TABLE `bestellingsorders` (
  `bestellingsId` int(11) NOT NULL,
  `orderId` int(10) NOT NULL,
  `productId` int(11) NOT NULL,
  `aantal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `bestellingsorders`
--

INSERT INTO `bestellingsorders` (`bestellingsId`, `orderId`, `productId`, `aantal`) VALUES
(23, 8, 1, 1),
(23, 9, 3, 2);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `klanten`
--

DROP TABLE IF EXISTS `klanten`;
CREATE TABLE `klanten` (
  `email` varchar(30) NOT NULL,
  `naam` varchar(20) NOT NULL,
  `vnaam` varchar(20) NOT NULL,
  `straat` varchar(50) NOT NULL,
  `huisnr` varchar(3) NOT NULL,
  `postcode` varchar(4) NOT NULL,
  `woonplaats` varchar(50) NOT NULL,
  `passwoord` varchar(40) NOT NULL,
  `blocked` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `klanten`
--

INSERT INTO `klanten` (`email`, `naam`, `vnaam`, `straat`, `huisnr`, `postcode`, `woonplaats`, `passwoord`, `blocked`) VALUES
('a@a.a', 'a', 'a', 'a', 'a', '3336', 'a', 'afa9e41cb84176730e98459a771faa9c7186c2ea', 0);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `producten`
--

DROP TABLE IF EXISTS `producten`;
CREATE TABLE `producten` (
  `productId` int(11) NOT NULL,
  `productNaam` text NOT NULL,
  `prijs` decimal(5,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `producten`
--

INSERT INTO `producten` (`productId`, `productNaam`, `prijs`) VALUES
(1, 'croissant', '1'),
(2, 'chocoladekoek', '1'),
(3, 'brood', '2'),
(4, 'frans brood', '2');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `bestellingen`
--
ALTER TABLE `bestellingen`
  ADD PRIMARY KEY (`bestellingsId`),
  ADD KEY `email` (`email`);

--
-- Indexen voor tabel `bestellingsorders`
--
ALTER TABLE `bestellingsorders`
  ADD PRIMARY KEY (`orderId`),
  ADD KEY `productId` (`productId`),
  ADD KEY `bestelling_ID` (`bestellingsId`);

--
-- Indexen voor tabel `klanten`
--
ALTER TABLE `klanten`
  ADD PRIMARY KEY (`email`);

--
-- Indexen voor tabel `producten`
--
ALTER TABLE `producten`
  ADD PRIMARY KEY (`productId`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `bestellingen`
--
ALTER TABLE `bestellingen`
  MODIFY `bestellingsId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT voor een tabel `bestellingsorders`
--
ALTER TABLE `bestellingsorders`
  MODIFY `orderId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT voor een tabel `producten`
--
ALTER TABLE `producten`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `bestellingsorders`
--
ALTER TABLE `bestellingsorders`
  ADD CONSTRAINT `bestellingsorders_ibfk_1` FOREIGN KEY (`productId`) REFERENCES `producten` (`productId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bestellingsorders_ibfk_2` FOREIGN KEY (`bestellingsId`) REFERENCES `bestellingen` (`bestellingsId`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
