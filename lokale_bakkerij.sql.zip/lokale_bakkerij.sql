-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Gegenereerd op: 28 jan 2016 om 00:10
-- Serverversie: 5.6.25
-- PHP-versie: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lokale_bakkerij`
--
CREATE DATABASE IF NOT EXISTS `lokale_bakkerij` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `lokale_bakkerij`;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `bestellingen`
--

DROP TABLE IF EXISTS `bestellingen`;
CREATE TABLE IF NOT EXISTS `bestellingen` (
  `email` varchar(30) NOT NULL,
  `orderId` int(11) NOT NULL,
  `bestellingsDatum` date NOT NULL,
  `afhaalDatum` date NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `bestellingsorders`
--

DROP TABLE IF EXISTS `bestellingsorders`;
CREATE TABLE IF NOT EXISTS `bestellingsorders` (
  `orderId` int(10) NOT NULL,
  `productId` int(11) NOT NULL,
  `aantal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `klanten`
--

DROP TABLE IF EXISTS `klanten`;
CREATE TABLE IF NOT EXISTS `klanten` (
  `email` varchar(30) NOT NULL,
  `naam` varchar(20) NOT NULL,
  `vnaam` varchar(20) NOT NULL,
  `straat` varchar(50) NOT NULL,
  `postcode` varchar(4) NOT NULL,
  `woonplaats` varchar(50) NOT NULL,
  `passwoord` varchar(6) NOT NULL,
  `blocked` tinyint(1) NOT NULL,
  `huisnr` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `klanten`
--

INSERT INTO `klanten` (`email`, `naam`, `vnaam`, `straat`, `postcode`, `woonplaats`, `passwoord`, `blocked`, `huisnr`) VALUES
('rgfd@gdfg.be', 'aezae', 'aeazea', 'zeazeaz', '6', '3360', 'RTgPc', 0, 'zea');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `producten`
--

DROP TABLE IF EXISTS `producten`;
CREATE TABLE IF NOT EXISTS `producten` (
  `productId` int(11) NOT NULL,
  `productNaam` text NOT NULL,
  `prijs` decimal(5,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `bestellingen`
--
ALTER TABLE `bestellingen`
  ADD KEY `email` (`email`),
  ADD KEY `orderId` (`orderId`);

--
-- Indexen voor tabel `bestellingsorders`
--
ALTER TABLE `bestellingsorders`
  ADD PRIMARY KEY (`orderId`),
  ADD KEY `productId` (`productId`);

--
-- Indexen voor tabel `klanten`
--
ALTER TABLE `klanten`
  ADD PRIMARY KEY (`email`);

--
-- Indexen voor tabel `producten`
--
ALTER TABLE `producten`
  ADD PRIMARY KEY (`productId`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `bestellingsorders`
--
ALTER TABLE `bestellingsorders`
  MODIFY `orderId` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT voor een tabel `producten`
--
ALTER TABLE `producten`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT;
--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `bestellingen`
--
ALTER TABLE `bestellingen`
  ADD CONSTRAINT `bestellingen_ibfk_1` FOREIGN KEY (`orderId`) REFERENCES `bestellingsorders` (`orderId`),
  ADD CONSTRAINT `bestellingen_ibfk_2` FOREIGN KEY (`email`) REFERENCES `klanten` (`email`);

--
-- Beperkingen voor tabel `bestellingsorders`
--
ALTER TABLE `bestellingsorders`
  ADD CONSTRAINT `bestellingsorders_ibfk_1` FOREIGN KEY (`productId`) REFERENCES `producten` (`productId`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
